package com.sparta.sw_backend_team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwBackendTeamApplicationTests {

    @Test
    void contextLoads() {
    }

}
