package com.sparta.sw_backend_team;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwBackendTeamApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwBackendTeamApplication.class, args);
    }

}
