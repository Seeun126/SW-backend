// src/main/resources/static/app.js
document.addEventListener('DOMContentLoaded', function() {
    console.log('Sport Match App is running!');
});
